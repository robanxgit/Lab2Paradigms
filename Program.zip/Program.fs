﻿type Coach = { Name: string; FormerPlayer: bool }
type Stats = { Wins: int; Losses: int }
type Team = { Name: string; Coach: Coach; Stats: Stats }


let teams = [
    { Name = "San Antonio Spurs"; Coach = { Name = "Gregg Popovich"; FormerPlayer = false }; Stats = { Wins = 2305; Losses = 1562 } }
    { Name = "Boston Celtics"; Coach = { Name = "Joe Mazzulla"; FormerPlayer = false }; Stats = { Wins = 3634; Losses = 2480 } }
    { Name = "Utah Jazz"; Coach = { Name = "Will Hardy"; FormerPlayer = false }; Stats = { Wins = 2177; Losses = 1855 } }
    { Name = "Miami Heat"; Coach = { Name = "Erik Spoelstra"; FormerPlayer = false }; Stats = { Wins = 1521; Losses = 1364 } }
    { Name = "Los Angeles Lakers"; Coach = { Name = "JJ Redick"; FormerPlayer = true }; Stats = { Wins = 3550; Losses = 2454 } }
]


let successfulTeams = 
    teams 
    |> List.filter (fun team -> team.Stats.Wins > team.Stats.Losses)


let teamSuccessPercentages = 
    successfulTeams 
    |> List.map (fun team -> 
        let wins = float team.Stats.Wins
        let losses = float team.Stats.Losses
        let successPercentage = (wins / (wins + losses)) * 100.0
        (team.Name, successPercentage)
    )


teamSuccessPercentages 
|> List.iter (fun (name, percentage) -> 
    printfn "Team: %s, Success Percentage: %.2f%%" name percentage
)







 //  Discriminated Union
type Cuisine =
    | Korean
    | Turkish


type MovieType =
    | Regular
    | IMAX
    | DBOX
    | RegularWithSnacks
    | IMAXWithSnacks
    | DBOXWithSnacks


type Activity =
    | BoardGame
    | Chill
    | Movie of MovieType
    | Restaurant of Cuisine
    | LongDrive of int * float 


let calculateBudget (activity: Activity) =
    match activity with
    | BoardGame -> 0.0 
    | Chill -> 0.0 
    | Movie movieType ->
        match movieType with
        | Regular -> 12.0
        | IMAX -> 17.0
        | DBOX -> 20.0
        | RegularWithSnacks -> 12.0 + 5.0
        | IMAXWithSnacks -> 17.0 + 5.0
        | DBOXWithSnacks -> 20.0 + 5.0
    | Restaurant cuisine ->
        match cuisine with
        | Korean -> 70.0
        | Turkish -> 65.0
    | LongDrive (kilometers, fuelCostPerKm) -> float kilometers * fuelCostPerKm


let valentineActivities = [
    BoardGame
    Chill
    Movie Regular
    Movie IMAXWithSnacks
    Restaurant Korean
    LongDrive (100, 1.5)
]


valentineActivities
|> List.iter (fun activity ->
    let cost = calculateBudget activity
    printfn "Activity: %A | Cost: %.2f CAD" activity cost
)
